class Subtract{
    static int sub(int a, int b){return a - b;}
    
    static int sub(int a, int b,  int c){return a - b- c;}
    
        
    
}
public class Main
{
	public static void main(String[] args) {
		System.out.println(Subtract.sub(4, 6));
		System.out.println(Subtract.sub(4,5,6));
		
	}
}
